

```python
#import H2O
import h2o
```


```python
#Intialize H2O
h2o.init()
```

    Checking whether there is an H2O instance running at http://localhost:54321..... not found.
    Attempting to start a local H2O server...
      Java Version: java version "1.7.0_80"; Java(TM) SE Runtime Environment (build 1.7.0_80-b15); Java HotSpot(TM) 64-Bit Server VM (build 24.80-b11, mixed mode)
      Starting server from /usr/local/lib/python3.6/site-packages/h2o/backend/bin/h2o.jar
      Ice root: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpd9mfjzow
      JVM stdout: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpd9mfjzow/h2o_pmelavoyraja_started_from_python.out
      JVM stderr: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpd9mfjzow/h2o_pmelavoyraja_started_from_python.err
      Server is running at http://127.0.0.1:54321
    Connecting to H2O server at http://127.0.0.1:54321... successful.



<div style="overflow:auto"><table style="width:50%"><tr><td>H2O cluster uptime:</td>
<td>02 secs</td></tr>
<tr><td>H2O cluster version:</td>
<td>3.10.3.4</td></tr>
<tr><td>H2O cluster version age:</td>
<td>1 month </td></tr>
<tr><td>H2O cluster name:</td>
<td>H2O_from_python_pmelavoyraja_eed171</td></tr>
<tr><td>H2O cluster total nodes:</td>
<td>1</td></tr>
<tr><td>H2O cluster free memory:</td>
<td>3.556 Gb</td></tr>
<tr><td>H2O cluster total cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster allowed cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster status:</td>
<td>accepting new members, healthy</td></tr>
<tr><td>H2O connection url:</td>
<td>http://127.0.0.1:54321</td></tr>
<tr><td>H2O connection proxy:</td>
<td>None</td></tr>
<tr><td>Python version:</td>
<td>3.6.0 final</td></tr></table></div>



```python
h2o.cluster().show_status()
```


<div style="overflow:auto"><table style="width:50%"><tr><td>H2O cluster uptime:</td>
<td>06 secs</td></tr>
<tr><td>H2O cluster version:</td>
<td>3.10.3.4</td></tr>
<tr><td>H2O cluster version age:</td>
<td>1 month </td></tr>
<tr><td>H2O cluster name:</td>
<td>H2O_from_python_pmelavoyraja_eed171</td></tr>
<tr><td>H2O cluster total nodes:</td>
<td>1</td></tr>
<tr><td>H2O cluster free memory:</td>
<td>3.556 Gb</td></tr>
<tr><td>H2O cluster total cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster allowed cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster status:</td>
<td>locked, healthy</td></tr>
<tr><td>H2O connection url:</td>
<td>http://127.0.0.1:54321</td></tr>
<tr><td>H2O connection proxy:</td>
<td>None</td></tr>
<tr><td>Python version:</td>
<td>3.6.0 final</td></tr></table></div>



```python
h2o.cluster().shutdown()
```

    H2O session _sid_9829 closed.



```python
h2o.init(max_mem_size_GB=8)
```

    Checking whether there is an H2O instance running at http://localhost:54321..... not found.
    Attempting to start a local H2O server...
      Java Version: java version "1.7.0_80"; Java(TM) SE Runtime Environment (build 1.7.0_80-b15); Java HotSpot(TM) 64-Bit Server VM (build 24.80-b11, mixed mode)
      Starting server from /usr/local/lib/python3.6/site-packages/h2o/backend/bin/h2o.jar
      Ice root: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpz51w2_iw
      JVM stdout: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpz51w2_iw/h2o_pmelavoyraja_started_from_python.out
      JVM stderr: /var/folders/kr/20wx8_317y743td_zsl2qmsm3kg48w/T/tmpz51w2_iw/h2o_pmelavoyraja_started_from_python.err
      Server is running at http://127.0.0.1:54321
    Connecting to H2O server at http://127.0.0.1:54321... successful.



<div style="overflow:auto"><table style="width:50%"><tr><td>H2O cluster uptime:</td>
<td>02 secs</td></tr>
<tr><td>H2O cluster version:</td>
<td>3.10.3.4</td></tr>
<tr><td>H2O cluster version age:</td>
<td>1 month </td></tr>
<tr><td>H2O cluster name:</td>
<td>H2O_from_python_pmelavoyraja_frdtn0</td></tr>
<tr><td>H2O cluster total nodes:</td>
<td>1</td></tr>
<tr><td>H2O cluster free memory:</td>
<td>7.111 Gb</td></tr>
<tr><td>H2O cluster total cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster allowed cores:</td>
<td>8</td></tr>
<tr><td>H2O cluster status:</td>
<td>accepting new members, healthy</td></tr>
<tr><td>H2O connection url:</td>
<td>http://127.0.0.1:54321</td></tr>
<tr><td>H2O connection proxy:</td>
<td>None</td></tr>
<tr><td>Python version:</td>
<td>3.6.0 final</td></tr></table></div>



```python
#Datasets URL
datasets = "https://raw.githubusercontent.com/DarrenCook/h2o/bk/datasets/"
```


```python
#Import IRIS Data Set
data = h2o.import_file(datasets + "iris_wheader.csv")
```

    Parse progress: |█████████████████████████████████████████████████████████| 100%



```python
data.head(5)
```


<table>
<thead>
<tr><th style="text-align: right;">  sepal_len</th><th style="text-align: right;">  sepal_wid</th><th style="text-align: right;">  petal_len</th><th style="text-align: right;">  petal_wid</th><th>class      </th></tr>
</thead>
<tbody>
<tr><td style="text-align: right;">        5.1</td><td style="text-align: right;">        3.5</td><td style="text-align: right;">        1.4</td><td style="text-align: right;">        0.2</td><td>Iris-setosa</td></tr>
<tr><td style="text-align: right;">        4.9</td><td style="text-align: right;">        3  </td><td style="text-align: right;">        1.4</td><td style="text-align: right;">        0.2</td><td>Iris-setosa</td></tr>
<tr><td style="text-align: right;">        4.7</td><td style="text-align: right;">        3.2</td><td style="text-align: right;">        1.3</td><td style="text-align: right;">        0.2</td><td>Iris-setosa</td></tr>
<tr><td style="text-align: right;">        4.6</td><td style="text-align: right;">        3.1</td><td style="text-align: right;">        1.5</td><td style="text-align: right;">        0.2</td><td>Iris-setosa</td></tr>
<tr><td style="text-align: right;">        5  </td><td style="text-align: right;">        3.6</td><td style="text-align: right;">        1.4</td><td style="text-align: right;">        0.2</td><td>Iris-setosa</td></tr>
</tbody>
</table>





    




```python
#Sample H2O Program of Deeplearning with IRIS Dataset
#Defining columns for X and Y
y = "class"
x = data.names
x.remove(y)
```


```python
#Split Data in 80 and 20 percent for training and testing the model
train, test = data.split_frame([0.8])
print(train.shape)
print(test.shape)

```

    (121, 5)
    (29, 5)



```python
#Build model with training data
m = h2o.estimators.deeplearning.H2ODeepLearningEstimator()
m.train(x, y, train)
```

    deeplearning Model Build progress: |██████████████████████████████████████| 100%



```python
#perdict or test the data agaisnt the above built model
p = m.predict(test)
```

    deeplearning prediction progress: |███████████████████████████████████████| 100%



```python
m.confusion_matrix(train)
```

    Confusion Matrix: vertical: actual; across: predicted
    



<div style="overflow:auto"><table style="width:50%"><tr><td><b>Iris-setosa</b></td>
<td><b>Iris-versicolor</b></td>
<td><b>Iris-virginica</b></td>
<td><b>Error</b></td>
<td><b>Rate</b></td></tr>
<tr><td>38.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0 / 38</td></tr>
<tr><td>0.0</td>
<td>46.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0 / 46</td></tr>
<tr><td>0.0</td>
<td>6.0</td>
<td>31.0</td>
<td>0.1621622</td>
<td>6 / 37</td></tr>
<tr><td>38.0</td>
<td>52.0</td>
<td>31.0</td>
<td>0.0495868</td>
<td>6 / 121</td></tr></table></div>





    




```python
m.model_performance(test)
```

    
    ModelMetricsMultinomial: deeplearning
    ** Reported on test data. **
    
    MSE: 0.09207034967528868
    RMSE: 0.303430963606697
    LogLoss: 0.43501094053640604
    Mean Per-Class Error: 0.07692307692307693
    Confusion Matrix: vertical: actual; across: predicted
    



<div style="overflow:auto"><table style="width:50%"><tr><td><b>Iris-setosa</b></td>
<td><b>Iris-versicolor</b></td>
<td><b>Iris-virginica</b></td>
<td><b>Error</b></td>
<td><b>Rate</b></td></tr>
<tr><td>12.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0 / 12</td></tr>
<tr><td>0.0</td>
<td>4.0</td>
<td>0.0</td>
<td>0.0</td>
<td>0 / 4</td></tr>
<tr><td>0.0</td>
<td>3.0</td>
<td>10.0</td>
<td>0.2307692</td>
<td>3 / 13</td></tr>
<tr><td>12.0</td>
<td>7.0</td>
<td>10.0</td>
<td>0.1034483</td>
<td>3 / 29</td></tr></table></div>


    Top-3 Hit Ratios: 



<div style="overflow:auto"><table style="width:50%"><tr><td><b>k</b></td>
<td><b>hit_ratio</b></td></tr>
<tr><td>1</td>
<td>0.8965517</td></tr>
<tr><td>2</td>
<td>1.0</td></tr>
<tr><td>3</td>
<td>1.0</td></tr></table></div>





    




```python
#Gradient Linear Model on Building Energy Efficency Dataset
data = h2o.import_file(datasets + "ENB2012_data.csv")
```

    Parse progress: |█████████████████████████████████████████████████████████| 100%



```python
'''
X1: Relative Compactness
X2: Surface Area
X3: Wall Area
X4: Roof Area
X5: Overall Height
X6: Orientation
X7: Glazing area
X8: Glazing area distribution
Y1: Heating Load
Y2: Cooling Load
'''
factorsList = ["X6", "X8"]
data[factorsList] = data[factorsList].asfactor()

train, test = data.split_frame([0.8])

x = [ "X2"]
y = "Y2"
```


```python
from h2o.estimators.glm import H2OGeneralizedLinearEstimator
m = H2OGeneralizedLinearEstimator(model_id="GLM_defaults", nfolds=10)
m.train(x, y, train)
```

    glm Model Build progress: |███████████████████████████████████████████████| 100%



```python
m.summary()
```

    GLM Model: summary
    



<div style="overflow:auto"><table style="width:50%"><tr><td><b></b></td>
<td><b>family</b></td>
<td><b>link</b></td>
<td><b>regularization</b></td>
<td><b>number_of_predictors_total</b></td>
<td><b>number_of_active_predictors</b></td>
<td><b>number_of_iterations</b></td>
<td><b>training_frame</b></td></tr>
<tr><td></td>
<td>gaussian</td>
<td>identity</td>
<td>Elastic Net (alpha = 0.5, lambda = 0.01278 )</td>
<td>1</td>
<td>1</td>
<td>0</td>
<td>py_246_sid_ba7e</td></tr></table></div>





    




```python
m.coef()
```




    {'Intercept': 73.46954619759163, 'X2': -0.0726464826953986}




```python
test['X2'].as_data_frame(use_pandas=True).values.tolist()
```




    [[514.5],
     [563.5],
     [588.0],
     [588.0],
     [612.5],
     [637.0],
     [661.5],
     [686.0],
     [710.5],
     [784.0],
     [808.5],
     [514.5],
     [563.5],
     [588.0],
     [612.5],
     [637.0],
     [661.5],
     [686.0],
     [710.5],
     [710.5],
     [735.0],
     [735.0],
     [759.5],
     [759.5],
     [759.5],
     [784.0],
     [808.5],
     [808.5],
     [563.5],
     [588.0],
     [637.0],
     [686.0],
     [710.5],
     [808.5],
     [514.5],
     [588.0],
     [588.0],
     [588.0],
     [637.0],
     [661.5],
     [514.5],
     [661.5],
     [686.0],
     [710.5],
     [759.5],
     [784.0],
     [784.0],
     [514.5],
     [514.5],
     [563.5],
     [588.0],
     [588.0],
     [612.5],
     [637.0],
     [686.0],
     [686.0],
     [686.0],
     [710.5],
     [735.0],
     [759.5],
     [808.5],
     [808.5],
     [588.0],
     [588.0],
     [612.5],
     [637.0],
     [661.5],
     [686.0],
     [710.5],
     [759.5],
     [784.0],
     [563.5],
     [563.5],
     [588.0],
     [612.5],
     [686.0],
     [808.5],
     [514.5],
     [514.5],
     [661.5],
     [661.5],
     [686.0],
     [710.5],
     [735.0],
     [735.0],
     [759.5],
     [759.5],
     [808.5],
     [808.5],
     [514.5],
     [612.5],
     [637.0],
     [637.0],
     [661.5],
     [710.5],
     [710.5],
     [735.0],
     [784.0],
     [808.5],
     [808.5],
     [514.5],
     [514.5],
     [588.0],
     [612.5],
     [710.5],
     [710.5],
     [735.0],
     [759.5],
     [808.5],
     [808.5],
     [514.5],
     [612.5],
     [637.0],
     [661.5],
     [661.5],
     [661.5],
     [710.5],
     [735.0],
     [784.0],
     [808.5],
     [514.5],
     [514.5],
     [563.5],
     [588.0],
     [588.0],
     [612.5],
     [637.0],
     [637.0],
     [686.0],
     [735.0],
     [735.0],
     [759.5],
     [784.0],
     [588.0],
     [661.5],
     [686.0],
     [686.0],
     [710.5],
     [735.0],
     [759.5],
     [784.0],
     [808.5],
     [808.5],
     [514.5],
     [563.5],
     [588.0],
     [612.5],
     [661.5],
     [686.0],
     [710.5],
     [759.5],
     [514.5],
     [563.5],
     [637.0],
     [710.5],
     [735.0],
     [759.5],
     [759.5],
     [784.0],
     [784.0],
     [784.0],
     [808.5]]




```python
p = m.predict(test)
p.shape
```

    glm prediction progress: |████████████████████████████████████████████████| 100%





    (162, 1)




```python
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
# Plot outputs
plt.scatter(test['X2'].as_data_frame(use_pandas=True).values.tolist(), test['Y2'].as_data_frame(use_pandas=True).values.tolist(),  color='black')
plt.plot(test['X2'].as_data_frame(use_pandas=True).values.tolist(), p.as_data_frame(use_pandas=True).values.tolist(),  color='blue',linewidth=3)
plt.xticks(())
plt.yticks(())

plt.xlabel('Surface Area')
plt.ylabel('Cooling Load')

plt.show()
```


![png](output_21_0.png)



```python
m
```

    Model Details
    =============
    H2OGeneralizedLinearEstimator :  Generalized Linear Modeling
    Model Key:  GLM_defaults
    
    
    ModelMetricsRegressionGLM: glm
    ** Reported on train data. **
    
    MSE: 49.66933718508467
    RMSE: 7.047647634855525
    MAE: 5.5518093437540115
    RMSLE: 0.27017008815017446
    R^2: 0.4515917881246475
    Mean Residual Deviance: 49.66933718508467
    Null degrees of freedom: 605
    Residual degrees of freedom: 604
    Null deviance: 54885.426006354224
    Residual deviance: 30099.61833416131
    AIC: 4092.418499747457
    
    ModelMetricsRegressionGLM: glm
    ** Reported on cross-validation data. **
    
    MSE: 49.944570087650455
    RMSE: 7.067147238288619
    MAE: 5.5624096125258555
    RMSLE: 0.27099499017385287
    R^2: 0.44855289144312593
    Mean Residual Deviance: 49.944570087650455
    Null degrees of freedom: 605
    Residual degrees of freedom: 604
    Null deviance: 55195.52039348384
    Residual deviance: 30266.409473116175
    AIC: 4095.767260336406
    Cross-Validation Metrics Summary: 



<div style="overflow:auto"><table style="width:50%"><tr><td><b></b></td>
<td><b>mean</b></td>
<td><b>sd</b></td>
<td><b>cv_1_valid</b></td>
<td><b>cv_2_valid</b></td>
<td><b>cv_3_valid</b></td>
<td><b>cv_4_valid</b></td>
<td><b>cv_5_valid</b></td>
<td><b>cv_6_valid</b></td>
<td><b>cv_7_valid</b></td>
<td><b>cv_8_valid</b></td>
<td><b>cv_9_valid</b></td>
<td><b>cv_10_valid</b></td></tr>
<tr><td>mae</td>
<td>5.5862656</td>
<td>0.5525004</td>
<td>5.190972</td>
<td>4.8841147</td>
<td>5.1683707</td>
<td>4.9646797</td>
<td>6.8410397</td>
<td>6.1438684</td>
<td>4.4815426</td>
<td>5.309821</td>
<td>6.0800176</td>
<td>6.798228</td></tr>
<tr><td>mse</td>
<td>50.370083</td>
<td>8.4214115</td>
<td>40.981586</td>
<td>43.310226</td>
<td>46.10145</td>
<td>39.789963</td>
<td>64.53393</td>
<td>60.800003</td>
<td>33.964657</td>
<td>48.110176</td>
<td>51.99028</td>
<td>74.11855</td></tr>
<tr><td>null_deviance</td>
<td>5519.5522</td>
<td>475.38834</td>
<td>5077.0874</td>
<td>5624.842</td>
<td>6717.2925</td>
<td>5319.744</td>
<td>4989.1943</td>
<td>6349.479</td>
<td>4191.4736</td>
<td>5720.5483</td>
<td>5761.6133</td>
<td>5444.245</td></tr>
<tr><td>r2</td>
<td>0.4326423</td>
<td>0.0766968</td>
<td>0.4520844</td>
<td>0.5181874</td>
<td>0.5124664</td>
<td>0.5640116</td>
<td>0.3077703</td>
<td>0.3961615</td>
<td>0.5597946</td>
<td>0.4297674</td>
<td>0.3775665</td>
<td>0.2086132</td></tr>
<tr><td>residual_deviance</td>
<td>3026.6409</td>
<td>439.5118</td>
<td>2663.8032</td>
<td>2685.2341</td>
<td>3273.203</td>
<td>2307.8179</td>
<td>3420.2983</td>
<td>3769.6</td>
<td>1800.1267</td>
<td>3030.941</td>
<td>3535.339</td>
<td>3780.0461</td></tr>
<tr><td>rmse</td>
<td>7.049492</td>
<td>0.5808381</td>
<td>6.401686</td>
<td>6.5810504</td>
<td>6.789805</td>
<td>6.3079286</td>
<td>8.033301</td>
<td>7.7974358</td>
<td>5.8279204</td>
<td>6.9361496</td>
<td>7.2104287</td>
<td>8.609213</td></tr>
<tr><td>rmsle</td>
<td>0.2704935</td>
<td>0.0176083</td>
<td>0.2592270</td>
<td>0.2559093</td>
<td>0.2619224</td>
<td>0.2535999</td>
<td>0.3225376</td>
<td>0.2929545</td>
<td>0.2506567</td>
<td>0.2344037</td>
<td>0.2922305</td>
<td>0.2814936</td></tr></table></div>


    Scoring History: 



<div style="overflow:auto"><table style="width:50%"><tr><td><b></b></td>
<td><b>timestamp</b></td>
<td><b>duration</b></td>
<td><b>iteration</b></td>
<td><b>negative_log_likelihood</b></td>
<td><b>objective</b></td></tr>
<tr><td></td>
<td>2017-03-03 21:17:20</td>
<td> 0.000 sec</td>
<td>0</td>
<td>54885.4267201</td>
<td>90.5700111</td></tr></table></div>





    




```python
p = m.model_performance(test)
p
```

    
    ModelMetricsRegressionGLM: glm
    ** Reported on test data. **
    
    MSE: 48.65025785134745
    RMSE: 6.97497368105052
    MAE: 5.541949687612305
    RMSLE: 0.2724197524210252
    R^2: 0.45560594746092564
    Mean Residual Deviance: 48.65025785134745
    Null degrees of freedom: 161
    Residual degrees of freedom: 160
    Null deviance: 14544.552312987205
    Residual deviance: 7881.341771918286
    AIC: 1095.0505363755613





    




```python
#K Means on Movies Data
tfidf = h2o.import_file(datasets+ "movie.tfidf.csv")
```

    Parse progress: |█████████████████████████████████████████████████████████| 100%



```python
tfidf.shape
```




    (100, 564)




```python
temp = list(range(1,564))
```


```python
#Build the model on K-Means clustering model on movies dataset
from h2o.estimators.kmeans import H2OKMeansEstimator
m = H2OKMeansEstimator(k=10, standardize=False, init="PlusPlus")
m.train(x=temp, training_frame=tfidf)
```

    kmeans Model Build progress: |████████████████████████████████████████████| 100%



```python
#Get the group that each movie is in
p = m.predict(tfidf)
```

    kmeans prediction progress: |█████████████████████████████████████████████| 100%



```python
#Join that to our movie names, then download it
d = tfidf[0].cbind(p).as_data_frame()
d.columns = ["movie","group"]

```


```python
d
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>movie</th>
      <th>group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>The Godfather</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>The Shawshank Redemption</td>
      <td>9</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Schindler's List</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Raging Bull</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Casablanca</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>One Flew Over Cuckoo Nest</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Gone with the Wind</td>
      <td>3</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Citizen Kane</td>
      <td>5</td>
    </tr>
    <tr>
      <th>8</th>
      <td>The Wizard of Oz</td>
      <td>2</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Titanic</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Lawrence of Arabia</td>
      <td>2</td>
    </tr>
    <tr>
      <th>11</th>
      <td>The Godfather: Part II</td>
      <td>3</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Psycho</td>
      <td>5</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Sunset Blvd.</td>
      <td>8</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Vertigo</td>
      <td>5</td>
    </tr>
    <tr>
      <th>15</th>
      <td>On the Waterfront</td>
      <td>5</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Forrest Gump</td>
      <td>5</td>
    </tr>
    <tr>
      <th>17</th>
      <td>The Sound of Music</td>
      <td>6</td>
    </tr>
    <tr>
      <th>18</th>
      <td>West Side Story</td>
      <td>8</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Star Wars</td>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>E.T. the Extra-Terrestrial</td>
      <td>5</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2001: A Space Odyssey</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>The Silence of the Lambs</td>
      <td>9</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Chinatown</td>
      <td>7</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Bridge on the River Kwai</td>
      <td>2</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Singin' in the Rain</td>
      <td>7</td>
    </tr>
    <tr>
      <th>26</th>
      <td>It's a Wonderful Life</td>
      <td>5</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Some Like It Hot</td>
      <td>5</td>
    </tr>
    <tr>
      <th>28</th>
      <td>12 Angry Men</td>
      <td>5</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Dr. Strangelove</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Rain Man</td>
      <td>5</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Annie Hall</td>
      <td>5</td>
    </tr>
    <tr>
      <th>72</th>
      <td>Out of Africa</td>
      <td>5</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Good Will Hunting</td>
      <td>5</td>
    </tr>
    <tr>
      <th>74</th>
      <td>Terms of Endearment</td>
      <td>5</td>
    </tr>
    <tr>
      <th>75</th>
      <td>Tootsie</td>
      <td>5</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Fargo</td>
      <td>1</td>
    </tr>
    <tr>
      <th>77</th>
      <td>Giant</td>
      <td>3</td>
    </tr>
    <tr>
      <th>78</th>
      <td>The Grapes of Wrath</td>
      <td>3</td>
    </tr>
    <tr>
      <th>79</th>
      <td>Shane</td>
      <td>4</td>
    </tr>
    <tr>
      <th>80</th>
      <td>The Green Mile</td>
      <td>5</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Close Encounters 3rd Kind</td>
      <td>0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Network</td>
      <td>0</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Nashville</td>
      <td>0</td>
    </tr>
    <tr>
      <th>84</th>
      <td>The Graduate</td>
      <td>5</td>
    </tr>
    <tr>
      <th>85</th>
      <td>American Graffiti</td>
      <td>5</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Pulp Fiction</td>
      <td>1</td>
    </tr>
    <tr>
      <th>87</th>
      <td>The African Queen</td>
      <td>6</td>
    </tr>
    <tr>
      <th>88</th>
      <td>Stagecoach</td>
      <td>2</td>
    </tr>
    <tr>
      <th>89</th>
      <td>Mutiny on the Bounty</td>
      <td>6</td>
    </tr>
    <tr>
      <th>90</th>
      <td>The Maltese Falcon</td>
      <td>1</td>
    </tr>
    <tr>
      <th>91</th>
      <td>A Clockwork Orange</td>
      <td>5</td>
    </tr>
    <tr>
      <th>92</th>
      <td>Taxi Driver</td>
      <td>4</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Wuthering Heights</td>
      <td>5</td>
    </tr>
    <tr>
      <th>94</th>
      <td>Double Indemnity</td>
      <td>1</td>
    </tr>
    <tr>
      <th>95</th>
      <td>Rebel Without Cause</td>
      <td>3</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Rear Window</td>
      <td>5</td>
    </tr>
    <tr>
      <th>97</th>
      <td>The Third Man</td>
      <td>5</td>
    </tr>
    <tr>
      <th>98</th>
      <td>North by Northwest</td>
      <td>5</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Yankee Doodle Dandy</td>
      <td>8</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 2 columns</p>
</div>




```python
#Iterate through and print each group
for ix, g in d.groupby("group"):
    print("---",ix,"---")
    print(', '.join(g["movie"]))
```

    --- 0 ---
    Titanic, Star Wars, 2001: A Space Odyssey, Jaws, The Exorcist, Close Encounters 3rd Kind, Network, Nashville
    --- 1 ---
    Unforgiven, To Kill a Mockingbird, Butch Cassidy & Sundance, Treasure of Sierra Madre, High Noon, Fargo, Pulp Fiction, The Maltese Falcon, Double Indemnity
    --- 2 ---
    Schindler's List, Casablanca, One Flew Over Cuckoo Nest, The Wizard of Oz, Lawrence of Arabia, Bridge on the River Kwai, Dr. Strangelove, Apocalypse Now, LOTR: Return of the King, Gladiator, From Here to Eternity, Raiders of the Lost Ark, Patton, Platoon, Dances with Wolves, The Deer Hunter, All Quiet on Western Front, Stagecoach
    --- 3 ---
    The Godfather, Gone with the Wind, The Godfather: Part II, Gandhi, Best Years of Our Lives, Ben-Hur, Doctor Zhivago, Braveheart, The Pianist, Goodfellas, Mr. Smith Goes Washington, Giant, The Grapes of Wrath, Rebel Without Cause
    --- 4 ---
    Saving Private Ryan, Shane, Taxi Driver
    --- 5 ---
    Raging Bull, Citizen Kane, Psycho, Vertigo, On the Waterfront, Forrest Gump, E.T. the Extra-Terrestrial, It's a Wonderful Life, Some Like It Hot, 12 Angry Men, Rocky, Streetcar Named Desire, Philadelphia Story, My Fair Lady, The Apartment, City Lights, The King's Speech, A Place in the Sun, Midnight Cowboy, Rain Man, Annie Hall, Out of Africa, Good Will Hunting, Terms of Endearment, Tootsie, The Green Mile, The Graduate, American Graffiti, A Clockwork Orange, Wuthering Heights, Rear Window, The Third Man, North by Northwest
    --- 6 ---
    The Sound of Music, The African Queen, Mutiny on the Bounty
    --- 7 ---
    Chinatown, Singin' in the Rain, Amadeus, Good, Bad and Ugly, It Happened One Night
    --- 8 ---
    Sunset Blvd., West Side Story, American in Paris, Yankee Doodle Dandy
    --- 9 ---
    The Shawshank Redemption, The Silence of the Lambs, The French Connection



```python
m
```

    Model Details
    =============
    H2OKMeansEstimator :  K-means
    Model Key:  KMeans_model_python_1488593802417_2
    
    
    ModelMetricsClustering: kmeans
    ** Reported on train data. **
    
    MSE: NaN
    RMSE: NaN
    Total Within Cluster Sum of Square Error: 65.31376126143456
    Total Sum of Square Error to Grand Mean: 77.19577796688563
    Between Cluster Sum of Square Error: 11.882016705451065
    Centroid Statistics: 



<div style="overflow:auto"><table style="width:50%"><tr><td><b></b></td>
<td><b>centroid</b></td>
<td><b>size</b></td>
<td><b>within_cluster_sum_of_squares</b></td></tr>
<tr><td></td>
<td>1.0</td>
<td>8.0</td>
<td>5.2497337</td></tr>
<tr><td></td>
<td>2.0</td>
<td>9.0</td>
<td>5.4820563</td></tr>
<tr><td></td>
<td>3.0</td>
<td>18.0</td>
<td>11.8382663</td></tr>
<tr><td></td>
<td>4.0</td>
<td>14.0</td>
<td>9.1317580</td></tr>
<tr><td></td>
<td>5.0</td>
<td>3.0</td>
<td>1.3520704</td></tr>
<tr><td></td>
<td>6.0</td>
<td>33.0</td>
<td>24.1174482</td></tr>
<tr><td></td>
<td>7.0</td>
<td>3.0</td>
<td>1.3336484</td></tr>
<tr><td></td>
<td>8.0</td>
<td>5.0</td>
<td>3.1437712</td></tr>
<tr><td></td>
<td>9.0</td>
<td>4.0</td>
<td>2.2587403</td></tr>
<tr><td></td>
<td>10.0</td>
<td>3.0</td>
<td>1.4062685</td></tr></table></div>


    Scoring History: 



<div style="overflow:auto"><table style="width:50%"><tr><td><b></b></td>
<td><b>timestamp</b></td>
<td><b>duration</b></td>
<td><b>iteration</b></td>
<td><b>number_of_reassigned_observations</b></td>
<td><b>within_cluster_sum_of_squares</b></td></tr>
<tr><td></td>
<td>2017-03-03 21:17:50</td>
<td> 0.010 sec</td>
<td>0.0</td>
<td>nan</td>
<td>nan</td></tr>
<tr><td></td>
<td>2017-03-03 21:17:50</td>
<td> 0.139 sec</td>
<td>1.0</td>
<td>100.0</td>
<td>120.0497855</td></tr>
<tr><td></td>
<td>2017-03-03 21:17:50</td>
<td> 0.150 sec</td>
<td>2.0</td>
<td>1.0</td>
<td>65.3738842</td></tr>
<tr><td></td>
<td>2017-03-03 21:17:50</td>
<td> 0.157 sec</td>
<td>3.0</td>
<td>0.0</td>
<td>65.3137613</td></tr></table></div>





    




```python
h2o.cluster().shutdown()
```

    H2O session _sid_ba7e closed.

