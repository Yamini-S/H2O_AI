

```R
if ("package:h2o" %in% search()) { detach("package:h2o", unload=TRUE) }
```

    [1] "A shutdown has been triggered. "
    


```R
if ("h2o" %in% rownames(installed.packages())) { remove.packages("h2o") }
```

    Removing package from 'C:/Users/Vaidehi Deshpande/Documents/R/win-library/3.3'
    (as 'lib' is unspecified)
    


```R
install.packages("h2o", repos=(c("http://cran.rstudio.com")))
```

    Installing package into 'C:/Users/Vaidehi Deshpande/Documents/R/win-library/3.3'
    (as 'lib' is unspecified)
    

    package 'h2o' successfully unpacked and MD5 sums checked
    
    The downloaded binary packages are in
    	C:\Users\Vaidehi Deshpande\AppData\Local\Temp\RtmpovrDfT\downloaded_packages
    


```R
library(h2o)
```

    
    ----------------------------------------------------------------------
    
    Your next step is to start H2O:
        > h2o.init()
    
    For H2O package documentation, ask for help:
        > ??h2o
    
    After starting H2O, you can use the Web UI at http://localhost:54321
    For more information visit http://docs.h2o.ai
    
    ----------------------------------------------------------------------
    
    
    Attaching package: 'h2o'
    
    The following objects are masked from 'package:stats':
    
        cor, sd, var
    
    The following objects are masked from 'package:base':
    
        %*%, %in%, &&, ||, apply, as.factor, as.numeric, colnames,
        colnames<-, ifelse, is.character, is.factor, is.numeric, log,
        log10, log1p, log2, round, signif, trunc
    
    


```R
h2o.init()
```

    
    H2O is not running yet, starting it now...
    
    Note:  In case of errors look at the following log files:
        C:\Users\VAIDEH~1\AppData\Local\Temp\RtmpovrDfT/h2o_Vaidehi_Deshpande_started_from_r.out
        C:\Users\VAIDEH~1\AppData\Local\Temp\RtmpovrDfT/h2o_Vaidehi_Deshpande_started_from_r.err
    
    
    Starting H2O JVM and connecting: .. Connection successful!
    
    R is connected to the H2O cluster: 
        H2O cluster uptime:         5 seconds 78 milliseconds 
        H2O cluster version:        3.10.3.6 
        H2O cluster version age:    10 days  
        H2O cluster name:           H2O_started_from_R_Vaidehi_Deshpande_fod506 
        H2O cluster total nodes:    1 
        H2O cluster total memory:   1.32 GB 
        H2O cluster total cores:    4 
        H2O cluster allowed cores:  2 
        H2O cluster healthy:        TRUE 
        H2O Connection ip:          localhost 
        H2O Connection port:        54321 
        H2O Connection proxy:       NA 
        R Version:                  R version 3.3.2 (2016-10-31) 
    
    Note:  As started, H2O is limited to the CRAN default of 2 CPUs.
           Shut down and restart H2O as shown below to use all your CPUs.
               > h2o.shutdown()
               > h2o.init(nthreads = -1)
    
    


```R
prostate.hex = h2o.uploadFile(path = system.file("extdata", "prostate.csv", package="h2o"), destination_frame = "prostate.hex")
```

      |======================================================================| 100%
    


```R
summary(prostate.hex)
```

    Warning message in summary.H2OFrame(prostate.hex):
    "Approximated quantiles computed! If you are interested in exact quantiles, please pass the `exact_quantiles=TRUE` parameter."


     ID               CAPSULE          AGE             RACE           
     Min.   :  1.00   Min.   :0.0000   Min.   :43.00   Min.   :0.000  
     1st Qu.: 95.75   1st Qu.:0.0000   1st Qu.:62.00   1st Qu.:1.000  
     Median :190.50   Median :0.0000   Median :67.00   Median :1.000  
     Mean   :190.50   Mean   :0.4026   Mean   :66.04   Mean   :1.087  
     3rd Qu.:285.25   3rd Qu.:1.0000   3rd Qu.:71.00   3rd Qu.:1.000  
     Max.   :380.00   Max.   :1.0000   Max.   :79.00   Max.   :2.000  
     DPROS           DCAPS           PSA               VOL            
     Min.   :1.000   Min.   :1.000   Min.   :  0.300   Min.   : 0.00  
     1st Qu.:1.000   1st Qu.:1.000   1st Qu.:  4.900   1st Qu.: 0.00  
     Median :2.000   Median :1.000   Median :  8.664   Median :14.20  
     Mean   :2.271   Mean   :1.108   Mean   : 15.409   Mean   :15.81  
     3rd Qu.:3.000   3rd Qu.:1.000   3rd Qu.: 17.063   3rd Qu.:26.40  
     Max.   :4.000   Max.   :2.000   Max.   :139.700   Max.   :97.60  
     GLEASON        
     Min.   :0.000  
     1st Qu.:6.000  
     Median :6.000  
     Mean   :6.384  
     3rd Qu.:7.000  
     Max.   :9.000  



```R
 prostate.glm = h2o.glm(x = c("AGE","RACE","PSA","DCAPS"), y = "CAPSULE", training_frame = prostate.hex, family = "binomial", alpha = 0.5)
```

      |======================================================================| 100%
    


```R
print(prostate.glm)
```

    Model Details:
    ==============
    
    H2OBinomialModel: glm
    Model ID:  GLM_model_R_1488586272945_1 
    GLM Model: summary
        family  link                                regularization
    1 binomial logit Elastic Net (alpha = 0.5, lambda = 3.247E-4 )
      number_of_predictors_total number_of_active_predictors number_of_iterations
    1                          4                           4                    4
      training_frame
    1   prostate.hex
    
    Coefficients: glm coefficients
          names coefficients standardized_coefficients
    1 Intercept    -1.114418                 -0.337704
    2       AGE    -0.010977                 -0.071648
    3      RACE    -0.623216                 -0.192433
    4     DCAPS     1.314591                  0.408386
    5       PSA     0.046892                  0.937727
    
    H2OBinomialMetrics: glm
    ** Reported on training data. **
    
    MSE:  0.2027036
    RMSE:  0.4502261
    LogLoss:  0.5914634
    Mean Per-Class Error:  0.3826121
    AUC:  0.717601
    Gini:  0.435202
    R^2:  0.1572256
    Null Deviance:  512.2888
    Residual Deviance:  449.5122
    AIC:  459.5122
    
    Confusion Matrix (vertical: actual; across: predicted) for F1-optimal threshold:
            0   1    Error      Rate
    0      80 147 0.647577  =147/227
    1      18 135 0.117647   =18/153
    Totals 98 282 0.434211  =165/380
    
    Maximum Metrics: Maximum metrics at their respective thresholds
                            metric threshold    value idx
    1                       max f1  0.284048 0.620690 274
    2                       max f2  0.207093 0.778230 360
    3                 max f0point5  0.413268 0.636672 108
    4                 max accuracy  0.413268 0.705263 108
    5                max precision  0.998478 1.000000   0
    6                   max recall  0.207093 1.000000 360
    7              max specificity  0.998478 1.000000   0
    8             max absolute_mcc  0.413268 0.369123 108
    9   max min_per_class_accuracy  0.331806 0.647577 176
    10 max mean_per_class_accuracy  0.373175 0.672123 126
    
    Gains/Lift Table: Extract with `h2o.gainsLift(<model>, <data>)` or `h2o.gainsLift(<model>, valid=<T/F>, xval=<T/F>)`
    
    
    


```R
 myLabels = c(prostate.glm@model$x, "Intercept")
plot(prostate.glm@model$coefficients, xaxt = "n", xlab = "Coefficients", ylab = "Values")
axis(1, at = 1:length(myLabels), labels = myLabels)
abline(h = 0, col = 2, lty = 2)
```


![png](output_9_0.png)



```R
#Random Forest algorithm: It is a decision tree algorithm also known as ensemble algorithm.
h2o.randomForest(x, y, train, nfolds = 10, model_id = "RF_defaults")
```


    Error in is.H2OFrame(training_frame): object 'train' not found
    Traceback:
    

    1. h2o.randomForest(x, y, train, nfolds = 10, model_id = "RF_defaults")

    2. is.H2OFrame(training_frame)



```R
y <- "CAPSULE"
```


```R
x <- c("AGE","RACE","PSA","DCAPS")
```


```R
h2o.randomForest(x, y, train, nfolds = 10, model_id = "RF_defaults")
```


    Error in is.H2OFrame(training_frame): object 'train' not found
    Traceback:
    

    1. h2o.randomForest(x, y, train, nfolds = 10, model_id = "RF_defaults")

    2. is.H2OFrame(training_frame)



```R
parts <- h2o.splitFrame(prostate.hex, 0.8)
```


```R
train <- parts[[1]]
```


```R
test <- parts[[2]]
```


```R

```


```R
m<-h2o.randomForest(x, y, train, nfolds = 10, model_id = "RF_defaults")
```

      |======================================================================| 100%
    


```R
h2o.performance(m, test)
```


    H2ORegressionMetrics: drf
    
    MSE:  0.2486146
    RMSE:  0.4986127
    MAE:  0.4099493
    RMSLE:  0.3476463
    Mean Residual Deviance :  0.2486146
    



```R
prostate.km = h2o.kmeans(prostate.hex, k = 10, x = c("AGE","RACE","GLEASON","CAPSULE","DCAPS"))
```

      |======================================================================| 100%
    


```R
prostate.ctrs = as.data.frame(prostate.km@model$centers)
```


```R
plot(prostate.ctrs[,1:2])
plot(prostate.ctrs[,3:4])
title("K-Means Centers for k = 10", outer = TRUE, line = -2.0)
```


![png](output_22_0.png)



![png](output_22_1.png)



```R
prostate.dl = h2o.deeplearning(x = c("AGE","RACE","GLEASON","CAPSULE","DCAPS"), training_frame = prostate.hex,
                               autoencoder = TRUE,
                               reproducible = T,
                               seed = 1234,
                               hidden = c(6,5,6), epochs = 50)
```

      |======================================================================| 100%
    


```R
prostate.anon = h2o.anomaly(prostate.dl, prostate.hex, per_feature=FALSE)
```


```R
head(prostate.anon)
```


<table>
<thead><tr><th scope=col>Reconstruction.MSE</th></tr></thead>
<tbody>
	<tr><td>0.03565900</td></tr>
	<tr><td>0.21069564</td></tr>
	<tr><td>0.21352539</td></tr>
	<tr><td>0.09269035</td></tr>
	<tr><td>0.03684484</td></tr>
	<tr><td>0.16138164</td></tr>
</tbody>
</table>




```R
err <- as.data.frame(prostate.anon)
```


```R
plot(sort(err$Reconstruction.MSE), main='Reconstruction Error')
```


![png](output_27_0.png)



```R

```
