

```R
library(h2o)
```

    
    ----------------------------------------------------------------------
    
    Your next step is to start H2O:
        > h2o.init()
    
    For H2O package documentation, ask for help:
        > ??h2o
    
    After starting H2O, you can use the Web UI at http://localhost:54321
    For more information visit http://docs.h2o.ai
    
    ----------------------------------------------------------------------
    
    
    Attaching package: 'h2o'
    
    The following objects are masked from 'package:stats':
    
        cor, sd, var
    
    The following objects are masked from 'package:base':
    
        %*%, %in%, &&, ||, apply, as.factor, as.numeric, colnames,
        colnames<-, ifelse, is.character, is.factor, is.numeric, log,
        log10, log1p, log2, round, signif, trunc
    
    


```R
h2o.init()
```

     Connection successful!
    
    R is connected to the H2O cluster: 
        H2O cluster uptime:         1 hours 1 minutes 
        H2O cluster version:        3.10.3.5 
        H2O cluster version age:    13 days  
        H2O cluster name:           H2O_started_from_R_Yamini_ech830 
        H2O cluster total nodes:    1 
        H2O cluster total memory:   1.59 GB 
        H2O cluster total cores:    4 
        H2O cluster allowed cores:  4 
        H2O cluster healthy:        TRUE 
        H2O Connection ip:          localhost 
        H2O Connection port:        54321 
        H2O Connection proxy:       NA 
        R Version:                  R version 3.3.2 (2016-10-31) 
    
    


```R
prosPath = system.file("extdata", "prostate.csv", package = "h2o")
prostate_df <- read.csv(prosPath)
```


```R
set.seed(1234)
random_splits <- runif(nrow(prostate_df))
train_df <- prostate_df[random_splits < .5,]
dim(train_df)
```


<ol class=list-inline>
	<li>193</li>
	<li>9</li>
</ol>




```R
head(train_df)
```


<table>
<thead><tr><th></th><th scope=col>ID</th><th scope=col>CAPSULE</th><th scope=col>AGE</th><th scope=col>RACE</th><th scope=col>DPROS</th><th scope=col>DCAPS</th><th scope=col>PSA</th><th scope=col>VOL</th><th scope=col>GLEASON</th></tr></thead>
<tbody>
	<tr><th scope=row>1</th><td> 1  </td><td>0   </td><td>65  </td><td>1   </td><td>2   </td><td>1   </td><td> 1.4</td><td> 0.0</td><td>6   </td></tr>
	<tr><th scope=row>7</th><td> 7  </td><td>0   </td><td>68  </td><td>2   </td><td>4   </td><td>2   </td><td>31.9</td><td> 0.0</td><td>7   </td></tr>
	<tr><th scope=row>8</th><td> 8  </td><td>0   </td><td>61  </td><td>2   </td><td>4   </td><td>2   </td><td>66.7</td><td>27.2</td><td>7   </td></tr>
	<tr><th scope=row>13</th><td>13  </td><td>1   </td><td>72  </td><td>1   </td><td>4   </td><td>2   </td><td>22.7</td><td> 0.0</td><td>9   </td></tr>
	<tr><th scope=row>15</th><td>15  </td><td>0   </td><td>75  </td><td>1   </td><td>1   </td><td>1   </td><td> 7.5</td><td> 0.0</td><td>5   </td></tr>
	<tr><th scope=row>17</th><td>17  </td><td>0   </td><td>75  </td><td>2   </td><td>1   </td><td>1   </td><td> 2.5</td><td> 0.0</td><td>5   </td></tr>
</tbody>
</table>




```R
validate_df <- prostate_df[random_splits >=.5,]
dim(validate_df)
```


<ol class=list-inline>
	<li>187</li>
	<li>9</li>
</ol>




```R
outcome_name <- 'CAPSULE'
feature_names <- setdiff(names(prostate_df), outcome_name)
```


```R
feature_names
```


<ol class=list-inline>
	<li>'ID'</li>
	<li>'AGE'</li>
	<li>'RACE'</li>
	<li>'DPROS'</li>
	<li>'DCAPS'</li>
	<li>'PSA'</li>
	<li>'VOL'</li>
	<li>'GLEASON'</li>
</ol>




```R
prostate.hex<-as.h2o(train_df, destination_frame="train.hex")
```

      |======================================================================| 100%
    


```R
head(prostate.hex)
```


<table>
<thead><tr><th scope=col>ID</th><th scope=col>CAPSULE</th><th scope=col>AGE</th><th scope=col>RACE</th><th scope=col>DPROS</th><th scope=col>DCAPS</th><th scope=col>PSA</th><th scope=col>VOL</th><th scope=col>GLEASON</th></tr></thead>
<tbody>
	<tr><td> 1  </td><td>0   </td><td>65  </td><td>1   </td><td>2   </td><td>1   </td><td> 1.4</td><td> 0.0</td><td>6   </td></tr>
	<tr><td> 7  </td><td>0   </td><td>68  </td><td>2   </td><td>4   </td><td>2   </td><td>31.9</td><td> 0.0</td><td>7   </td></tr>
	<tr><td> 8  </td><td>0   </td><td>61  </td><td>2   </td><td>4   </td><td>2   </td><td>66.7</td><td>27.2</td><td>7   </td></tr>
	<tr><td>13  </td><td>1   </td><td>72  </td><td>1   </td><td>4   </td><td>2   </td><td>22.7</td><td> 0.0</td><td>9   </td></tr>
	<tr><td>15  </td><td>0   </td><td>75  </td><td>1   </td><td>1   </td><td>1   </td><td> 7.5</td><td> 0.0</td><td>5   </td></tr>
	<tr><td>17  </td><td>0   </td><td>75  </td><td>2   </td><td>1   </td><td>1   </td><td> 2.5</td><td> 0.0</td><td>5   </td></tr>
</tbody>
</table>




```R
prostate.dl = h2o.deeplearning(x = feature_names, training_frame = prostate.hex,
                               autoencoder = TRUE,
                               reproducible = T,
                               seed = 1234,
                               hidden = c(6,5,6), epochs = 50)
```

      |======================================================================| 100%
    


```R
prostate.dl
```


    Model Details:
    ==============
    
    H2OAutoEncoderModel: deeplearning
    Model ID:  DeepLearning_model_R_1488573890941_1 
    Status of Neuron Layers: auto-encoder, gaussian distribution, Quadratic loss, 181 weights/biases, 6.9 KB, 2,316 training samples, mini-batch size 1
      layer units      type dropout       l1       l2 mean_rate rate_rms momentum
    1     1     8     Input  0.00 %                                              
    2     2     6 Rectifier  0.00 % 0.000000 0.000000  0.007952 0.003614 0.000000
    3     3     5 Rectifier  0.00 % 0.000000 0.000000  0.003152 0.001663 0.000000
    4     4     6 Rectifier  0.00 % 0.000000 0.000000  0.002366 0.001949 0.000000
    5     5     8 Rectifier         0.000000 0.000000  0.003682 0.005102 0.000000
      mean_weight weight_rms mean_bias bias_rms
    1                                          
    2    0.033625   0.419705  0.526721 0.253438
    3   -0.112884   0.399731  0.983416 0.098159
    4   -0.007209   0.457098  1.001498 0.116803
    5   -0.123573   0.380468 -0.052076 0.049782
    
    
    H2OAutoEncoderMetrics: deeplearning
    ** Reported on training data. **
    
    Training Set Metrics: 
    =====================
    
    MSE: (Extract with `h2o.mse`) 0.05015752
    RMSE: (Extract with `h2o.rmse`) 0.2239587
    
    
    



```R
prostate.anon = h2o.anomaly(prostate.dl, prostate.hex, per_feature=FALSE)
head(prostate.anon)
```


<table>
<thead><tr><th scope=col>Reconstruction.MSE</th></tr></thead>
<tbody>
	<tr><td>0.03988444</td></tr>
	<tr><td>0.14211926</td></tr>
	<tr><td>0.17585169</td></tr>
	<tr><td>0.10316385</td></tr>
	<tr><td>0.07844050</td></tr>
	<tr><td>0.10470483</td></tr>
</tbody>
</table>




```R
err <- as.data.frame(prostate.anon)
```


```R
plot(sort(err$Reconstruction.MSE), main='Reconstruction Error')
```


![png](output_14_0.png)



```R

```
